/* cpm.c
   Useful functions for Workshop E
*/
#include <stdio.h>	/* Header for 'printf' function */
#include <string.h> /* Header for 'memset' function */
#include <stdlib.h> /* Header for 'exit' function */
#include "cpm.h"

unsigned char bitmap[BIT_MAP_LENG];
struct CPMdirent directory[TOTAL_FILES_NUMBER];

void viewBitmap()
{
    int row = 0;
    int col = 0;
    int block_post = 0;

    printf("\n\n");
    for (row = 0; row < BIT_MAP_LENG; row++) {

        /* row index */
        printf("%d\t",row);

        /* Bitmap status detail */
        for(col = 0; col < 8; col++) {

            /* Block 0 is occupied by directory itself
               Others blocks is occupied if block_status equal to '1'
            */
            block_post = 8*row + col;
            if((block_status(block_post) != 0) || (block_post == 0)) {
                printf("1, ");
            } else {
                printf("0, ");
            }
        }
        printf("\n");
    }
    printf("\n\n");
}

int openCreate(char *name, char * type)
{

    int i = 0;
    if(name == NULL) {
        printf(" Error! Not allow file name is NULL\n");
    }
    if(type == NULL) {
        printf(" Error! Not allow file type is NULL\n");
    }
    if(strlen(name) > 8) {
        printf(" Error! Not allow file name include more than %d characters\n", 8);
        return -2;
    }
    if(strlen(type) > 3) {
        printf(" Error! Not allow file type include more than %d characters\n", 3);
        return -2;
    }
    /* Return position of the file. */
    for(i = 0; i < TOTAL_FILES_NUMBER; i++) {
        if((strcmp(directory[i].filename, name) == 0) && (strcmp(directory[i].filetype, type) == 0))
        {
            printf(" Open file '%s.%s'\n", directory[i].filename, directory[i].filetype);
            return i;
        }
    }

    /* Create file */
    for(i = 0; i < TOTAL_FILES_NUMBER; i++) {
        /*  In case the entry is not occupied by a file
        	The file name and file type will be empty
        */
        if(strlen(directory[i].filename) == 0) {
            directory[i].usercode = 1;
            memcpy(directory[i].filename, name, strlen(name) + 1);
            memcpy(directory[i].filetype, type, strlen(type) + 1);
            printf(" Create file %s.%s \n", name, type);
            return -1;
        }
    }
    printf(" ERROR! Count not Open/Create file\n");
    return -2;
}

int toggle_bit(int block)
{

    int elem=block/8;
    int pos=block%8;
    int mask=1<<pos;

    bitmap[elem]^=mask;

    return bitmap[elem]&mask;
}


int block_status(int block)
{
    int elem=block/8;
    int pos=block%8;
    int mask=1<<pos;

    return bitmap[elem]&mask;
}

void diskFormat()
{
    /* Set empty bitmap, directory */
    memset(bitmap, 0, sizeof(bitmap));
    memset(directory, 0, sizeof(directory));

    /* By default, directory occupies the first block */
    toggle_bit(0);

    /* View bitmap status. */
    viewBitmap();
}

void viewDir()
{
    int i = 0;
    int empty = 1;

    printf("\n\n");
    printf(" File name\t\tFile type\t\tFile size\n");
	printf(" --------------------------------------------------------\n");

    /* Display all file information
     */
    for(i = 0; i < TOTAL_FILES_NUMBER; i++) {
        if(strlen(directory[i].filename) >= 1) {
            printf(" %s\t\t\t%s\t\t\t%d(KB)\n", directory[i].filename, directory[i].filetype, (directory[i].blockcount * 4));
            empty = 0;
        }
    }
    /* Just in case there is no file in directory */
    if(empty) {
        printf(" Empty directory! Please create some file then view directory again\n");
    }
    printf("\n\n");
}


int main ()
{
    int input = -1;
    int fIndex = -1;

    /* CP/M simulation main loop */
    for(;;) {
        /* Display menu */
        printf("\n\n");
        printf("1> Initialise Disk\n");
        printf("2> List Files in the Directory\n");
        printf("3> Display the Free Bitmap\n");
        printf("4> Open/Create File\n");
        printf("5> Read File\n");
        printf("6> Write File\n");
        printf("7> Delete File\n");
        printf("\n8> Exit\n\n");
        printf("Select number:>\t");

        /* Get input key.
        */
        scanf("%d", &input);

        /* Remove all characters from stdin buffer.
           Avoid wrong input value of the next time scanf().
        */
        while (getchar() != '\n');

        /* Simulate.
        */
        switch(input)
        {
        case 1:
            /* Format disk,
               make empty disk with empty directory
            */
            diskFormat();
            break;
        case 2:
            /* List file in directory. */
            viewDir();
            break;
        case 3:
            /* Display the free bitmap all blocks of the disk */
            viewBitmap();
            break;
        case 4:
        {
            char name[9];
            char type[4];
            printf("\n\n");
            /* Get the file name, type */
            printf(" Input name> ");
            /* make sure the name is empty before input then scan input */
            memset(name, 0, 9*sizeof(char));
            scanf("%s", name);

            /* reset input */
            while (getchar() != '\n');
            printf(" Input type> ");
            /* make sure the type is empty before input then scan input */
            memset(type, 0, 4*sizeof(char));

            scanf("%s", type);

            /* reset input */
            while (getchar() != '\n');

            fIndex = openCreate(name, type);
            printf("\n\n");
        }
        break;
        case 5:
        {
            int i = 0;
            printf("\n\n");
            if(fIndex >= 0) {
                printf(" The File '%s.%s' occupies blocks : ", directory[fIndex].filename, directory[fIndex].filetype);
                /* Display only block which actual occupied by a file */
                for (i=0; i<directory[fIndex].blockcount; i++)
                {
                    printf("%d, ", directory[fIndex].blocks[i]);
                }
                printf("\n");
            }
            /* File must be open before read */
            else {
                printf(" Error! Not any opened file, must open before read\n");
            }
            printf("\n\n");
        }
        break;
        case 6:
        {
            int write = 0;
            int i = 0;
            printf("\n\n");

            /* File must be open before write */
            if(fIndex < 0) {
                fprintf(stderr, " Error! There is no open file, must open before write!\n");
                break;
            }

            /* File size is limited by 64 KB */
            if(directory[fIndex].blockcount == 16) {
                fprintf(stderr, " File size limit is 64KB, lost data!\n");
                break;
            }

            /* Write data if a free block is available */
            for (i=1; i < NUMBER_OF_BLOCK; i++) {
                if(block_status(i) == 0) {
                    write = 1;
                    directory[fIndex].blocks[(int)directory[fIndex].blockcount++] = i;
                    toggle_bit(i);
                    printf(" Allocate the disk's block No.%d to the file \"%s.%s\"\n", i, directory[fIndex].filename, directory[fIndex].filetype);
                    break;
                }
            }

            /* Not write -> disk full */
            if(!write) {
                fprintf(stderr, " Disk full, not write data!\n");
            }
            printf("\n\n");
        }
        break;
        case 7:
        {
            int i = 0;
            printf("\n\n");
            if(fIndex >= TOTAL_FILES_NUMBER) {
                printf(" Total only 128 file!");
                break;
            }
            if(fIndex >= 0) {
                /* Deallocate blocks which occupied by the file to be deleted */
                for(i=0; i<directory[fIndex].blockcount; i++)
                {
                    toggle_bit(directory[fIndex].blocks[i]);
                }

                /* Delete file, reset appropriate entry */
                printf(" Deleted file '%s.%s'\n",directory[fIndex].filename, directory[fIndex].filetype);
                memset(directory[fIndex].filename, 0, 9*sizeof(char));
                memset(directory[fIndex].filetype, 0, 4*sizeof(char));
                memset(directory[fIndex].blocks, 0, 16*sizeof(char));
                directory[fIndex].blockcount = 0;

                /*Set default status */
                fIndex = -1;
            } else {
                printf(" No file open, need open a file before delete!\n");
            }
            printf("\n\n");
        }
        break;
        /* Exit if user input '8' from keyboard */
        case 8:
            exit(0);
        default:
            break;
        }
    }
    return 0;
}