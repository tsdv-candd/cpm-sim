/* cpm.c
   Useful functions for Workshop E
*/
#include <stdio.h>	/* For using printf function */
#include <string.h> /* For using memset function */
#include"cpm.h"

unsigned char bitmap[12];
struct CPMdirent directory[128];

void viewBitmap()
{
    int row =0;
    int col = 0;
    int block_post = 0;

    printf("\n\n");
    for (row = 0; row < 12; row++) {

        /* row index */
        printf("%d\t",row);

        /* Bitmap status detail */
        for(col = 0; col < 8; col++) {

            /* Block 0 is occupied by directory itself
               Others blocks is occupied if block_status equal to '1'
            */
            block_post = 8*row + col;
            if((block_status(block_post) != 0) || (block_post == 0)) {
                printf("1, ");
            } else {
                printf("0, ");
            }
        }
        printf("\n");
    }
    printf("\n\n");
}

int openCreate(char name[9], char type[4])
{

    int i = 0;

    /* Return position of the file. */
    for(i = 0; i < 128; i++) {
        if((strcmp(directory[i].filename, name) == 0) && (strcmp(directory[i].filetype, type) == 0))
        {
            printf("\tOpen file %s.%s\n", directory[i].filename, directory[i].filetype);
            return i;
        }
    }

    /* Create file */
    for(i = 0; i < 128; i++) {
        if(strcmp(directory[i].filename,"") == 0) {
            directory[i].usercode = 1;
            strcat(directory[i].filename, name);
            strcat(directory[i].filetype, type);
            return -1;
        }
    }
    return -2;
}

int toggle_bit(int block)
{

    int elem=block/8;
    int pos=block%8;
    int mask=1<<pos;

    bitmap[elem]^=mask;

    return bitmap[elem]&mask;
}


int block_status(int block)
{
    int elem=block/8;
    int pos=block%8;
    int mask=1<<pos;

    return bitmap[elem]&mask;
}

void diskFormat()
{
    /* Set empty bitmap, directory */
    memset(bitmap, 0, sizeof(bitmap));
    memset(directory, 0, sizeof(directory));

    /* By default, directory occupies the first block */
    toggle_bit(0);

    /* View bitmap status. */
    viewBitmap();
}

void viewDir()
{
    int i = 0;
    int empty = 1;

    printf("\n\n");
    printf(" File name\t\tFile type\t\tFile size,\n");

    /* Display all file information
     */
    for(i = 0; i < 128; i++) {
        if(strlen(directory[i].filename) > 0) {
            printf(" %s\t\t\t%s\t\t\t%d(KB)\n", directory[i].filename, directory[i].filetype, (directory[i].blockcount * 4));
            empty = 0;
        }
    }
    /* Just in case there is no file in directory */
    if(empty) {
        printf(" Empty directory! Please create some file then view directory again\n");
    }
    printf("\n\n");
}


int main ()
{
    int input = -1;
    int fIndex = -1;

    /* CP/M simulation main loop.
     */
    do {
        /* Display menu */
		printf("\n\n");
        printf("1>Initialise Disk\n");
        printf("2>List Files in the Directory\n");
        printf("3>Display the Free Bitmap\n");
        printf("4>Open/Create File\n");
        printf("5>Read File\n");
        printf("6>Write File\n");
        printf("7>Delete File\n");
        printf("\n8>Exit\n\n");
        printf("Select number:\t");

        /* Get input key.
        */
        scanf("%d", &input);

        /* Remove all characters from stdin buffer.
           Avoid wrong input value of the next time scanf().
        */
        while (getchar() != '\n');

        /* Simulate.
        */
        switch(input)
        {
        case 1:
            /* Format disk,
               make empty disk with empty directory
            */
            diskFormat();
            break;
        case 2:
            /* List file in directory. */
            viewDir();
            break;
        case 3:
            /* Display the free bitmap all blocks of the disk */
            viewBitmap();
            break;
        case 4:
        {
            char name[9];
            char type[4];
            printf("\n\n");
            /* Get the file name, type */
            printf(" Input name> ");
            scanf("%s", name);

            /* reset input */
            while (getchar() != '\n');
            printf(" Input type> ");
            scanf("%s", type);

            /* reset input */
            while (getchar() != '\n');
            fIndex = openCreate(name, type);

            /* Display open result. */
            if (fIndex == -2) {
                printf(" Open/Create file Error!\n");
            } else if (fIndex == -1) {
                printf(" Create File '%s.%s'\n",name, type);
            } else if(fIndex >= 0) {
                printf(" Open File '%s.%s'\n", directory[fIndex].filename, directory[fIndex].filetype);
            }
            printf("\n\n");
        }
        break;
        case 5:
        {
            int i = 0;
            printf("\n\n");
            if(fIndex >= 0) {
                printf(" The File '%s.%s' occupies blocks : ", directory[fIndex].filename, directory[fIndex].filetype);
                for (i=0; i<16; i++)
                {
                    printf("%d, ", directory[fIndex].blocks[i]);
                }
                printf("\n");
            }
            /* File must be open before read */
            else {
                printf(" Not any opened file! must open before read!\n");
            }
            printf("\n\n");
        }
        break;
        case 6:
        {
            int write = 0;
            int i = 0;
            printf("\n\n");

            /* File must be open before write */
            if(fIndex < 0) {
                fprintf(stderr, " There is no open file, must open before write!\n");
                break;
            }

            /* File size is limited by 64 KB */
            if(directory[fIndex].blockcount == 16) {
                fprintf(stderr, " File size's limit is 64KB, lost data!\n");
                break;
            }

            /* Write data if a free block is available */
            for (i=1; i<90; i++) {
                if(block_status(i) == 0) {
                    write = 1;
                    directory[fIndex].blocks[(int)directory[fIndex].blockcount++] = i;
                    toggle_bit(i);
                    printf(" Write file data at the block: %d\n", i);
                    break;
                }
            }

            /* Not write -> disk full */
            if(!write) {
                fprintf(stderr, " Disk full, not write data!\n");
            }
            printf("\n\n");
        }
        break;
        case 7:
        {
            int i = 0;
            printf("\n\n");
            if(fIndex > 128) {
                printf(" Total only 128 file!");
                break;
            }
            if(fIndex >= 0) {
                /* Deallocate blocks which occupied by the file to be deleted */
                for(i=0; i<directory[fIndex].blockcount; i++)
                {
                    toggle_bit(directory[fIndex].blocks[i]);
                }

                /* Delete file, reset appropriate entry */
                printf(" Deleted file '%s.%s'\n",directory[fIndex].filename, directory[fIndex].filetype);
                memset(directory[fIndex].filename, 0, 9*sizeof(char));
                memset(directory[fIndex].filetype, 0, 4*sizeof(char));
                memset(directory[fIndex].blocks, 0, 16*sizeof(char));
                directory[fIndex].blockcount = 0;

                /*Set default status */
                fIndex = -1;
            } else {
                printf(" No file open, need open a file before delete!\n");
            }
            printf("\n\n");
        }
        break;
        /* Exit if user input '8' from keyboard */
        case 8:
            fIndex = -1;
        default:
            break;
        }
    }
    /* Exit if user input key number '8' from keyboard*/
    while (input != 8);
    return 0;
}