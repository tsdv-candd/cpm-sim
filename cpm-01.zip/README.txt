			Explanation for the workshopE - CP/M simulation

1. Introduction:
===============
    This document aim to explain solution for the workshopE's requirement specification
    The information in this document include design information for functions.
	Also include how to build and run the simulation on Linux environment.
	
	Components of the release
	├── cpm.c 						-> Source code included implement of simulation
	├── cpm.h 						-> Header file.
	├── Instruction_WorkShopE.pdf 	-> requirement specification.
	├── Makefile 					-> Make file to build program.
	└── README.txt 					-> Document (This file)

   
    How to compile the source code:
    ------------------------------
    Run 'make' command.
    $ make
    Executable file name 'cpm' will be generate after above command - CP/M simulation execution.

2. How to use:
=============
	Refer to 'Instruction_WorkShopE.pdf' -> page [4] -> section 3 to get overview about 
	CP/M file system specification.
	Initialise Disk.
	List Files in the Directory.
	Display the Free Bitmap.
	Open/Create File.
	Read File.
	Write File
	Delete file
	Exit.

3. Function detail explain:
===========================
	3-1. int toggle_bit(int block);
		Toggles the value of the bit block, in
		the external array bitmap.
		returns the current value of the bit
		Does NOT validate block!!!
	
	3-2. int block_status(int block);
		Returns if block block is allocated
		returns 0 if bitmap bit is 0, not
		0 if bitmap bit is 1
		Does NOT validate block!!!

	3-3. void diskFormat();
		diskFormat : Create empty disk with empty directory.
		returns : None

	3-4. void viewDir();
		List all file in the directory.
		Returns nothing.

	3-5 void viewBitmap();
		Display bit map status.
		0 the block is free
		1 the block is occupied
		Note: The block0 is defaulted occupied by the directory entry.

	3-6. int openCreate(char name[9], char type[4]);
		Open/Create a file, if the file name specified is not in the directory, 
		a new file will be created.
		param : char name[9] - file name to open.
		param : char type[4] - file type
		return : return index of the file if it existed
	 		return -1 of the file is open
	 		return -2 other error.