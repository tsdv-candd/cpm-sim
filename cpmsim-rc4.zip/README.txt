===============================================================================================
			Solution explanation for the workshopE - CP/M simulation
===============================================================================================

1. Introduction:
~~~~~~~~~~~~~~~
    This document aim to explain solution for the requirement in workshopE.
    This workshop's requirement is implementing a File system simulator, based on the CP/M File system.
	
	Material for this presentation:
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    cpmold.c	: The original source code of the given by the workshopE.
    cpm.c       : The source code which already modify to resolve the problems.
    Makefile    : The make file used for compile cp1old.c and cp1.c to executable file.
    
    How to build program:
    ~~~~~~~~~~~~~~~~~~~~
    Simply run the make command under WorkShopE
    $ make
    After running make command, two executable files will be output:
    cpmsim		: The binary (executable file) which compiled from the source code cpm.c and cpm.h
				This executable is the operation of the CP/M simulation.

2. Overview about CP/M simulation requirement.
	. The disk size is 360 kbyte.
	. The smallest unit of allocation is 4 kbyte (block size = 4 kbyte)
		-> Total number of block = 360/4 = 90 blocks.
		Each bitmap array element (1 byte) can represent 8 block then the bitmap array need 90/8 = 11.2 element round up to 12.

	. The maximum size of a file is 64 kbytes, each directory entry included 16 blocks of disk, 16 * 4 = 64.
		-> So there is only one directory entry per file.

	. The main directory occupies the first block of the disk (block 0), and its size is fixed at 1 block, 
		-> So there can only be 128 files in this file system.
		Then the directory entry need 128 element to store file control information.

	. As the directory always occupies only the first block, therefore no control information about it
	needs to be stored in the directory (i.e. no . entry).
	
3. Detail about the CP/M simulation solution
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	The task is to implement disk initialisation, including:
	creating the root directory, and a free bitmap for this disk.
	specify an empty directory ...etc. All of these operation are simulate by following operation menu.
	
	3.1 Initialise Disk.
	Create and initialise disk control structures 
	Refer to the source file : cpm.c -> line 23 - line25
	Disk initialise operation is implemented by the function "disk_init" -> section 4.1. disk_init

4. Detail explanation for each function added to the file cpm.c
	
	4.1. disk_init() : initialise the disk.

	
	
	
	
	