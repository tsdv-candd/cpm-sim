#ifndef CPM_H
#define CPM_H
/* Prevent multiple inclusion */


/* cpm.h
   Various definitions for Workshop E
*/
/* Define */
#define BITMAP_LENGHT 	12		/* Bit map size in bytes */
#define ENTRIES_NUM 	128		/* Number of directory */
#define FILE_NAME_LEN 	8		/* Lenght of the file name */
#define FILE_TYPE_LEN 	3		/* Lenght of the file name */
#define BLOCKS_PER_FILE 16		/* Number of block in each file */
#define DISK_CAPACITY	360		/* Capacity of the disk in KB */
#define BLOCK_SIE		4 		/* Size of each block in KB */
#define NUMBER_OF_BLOCK (DISK_CAPACITY/BLOCK_SIE)
/* The bitmap */
extern unsigned char bitmap[BITMAP_LENGHT];
/* 360Kb disk with 4Kb blocks -> 11.25 bytes for bitmap
   so round up to 12 */

/* The directory entry */
struct CPMdirent
{
    signed char usercode;
    char filename[9];
    char filetype[4];
    char extent;
    char blockcount;
    char blocks[16];
};
/* Modelled on the description in [1].

   The two unused bytes have been added to the
   end of the two name parameters to allow them
   to be C strings
*/

/* The Directory */
//extern struct CPMdirent directory[32];
extern struct CPMdirent directory[ENTRIES_NUM];

/* Enum type for display the menu */
typedef enum {
    EXIT = 0,
    INIT_DISK,
    LIST_FILE,
    DISPLAY_FREE_BITMAP,
    OPEN_CREATE_FILE,
    READ_FILE,
    WRITE_FILE,
    DELETE_FILE
} menu_type;

int toggle_bit(int block);
/* Toggles the value of the bit block, in
   the external array bitmap.
   returns the current value of the bit
   Does NOT validate block!!!
*/
int block_status(int block);
/* Returns if block block is allocated
   returns 0 if bitmap bit is 0, not
   0 if bitmap bit is 1
   Does NOT validate block!!!
*/
menu_type menu();
/* Display the operation menu of the pcm simulator
 * Get the appropriate selected value of the user.
 * param : None.
 * return : return the appropriate value to the user selected key.
 */

void disk_init ();
/* Disk initialise : initialise the content of the Disk.
 * param : None
 * return : None
 */

void list_file_in_dir();
/* List all file in the directory.
 * param : None.
 * Return : None.
 */

void disp_bit_map();
/* Display bit map status.
 * Display status of all disk block in a table.
 * Each block status is presented by a cell
 * If the block is free - the cell value will be '0'
 * If the block is occupied - the cell value will be '1'
 * Note: The block0 is defaulted occupied by the directory entry.
 * Then the status of the block0 is not display here.
 * param : None.
 * Return : None.
 */

int open_create_file(char *fname, char *ftype);
/* Open/Create file if the file name specified is not in the directory,
 * a new file will be created.
 * param : char * fname - pointer to the string of file name.
 * param : char * ftype - pointer to the string of file type.
 * return : return position of a file in case the file already existed.
 * 			return -1 of the file is open (file have not existed).
 *			return -2 if error happened (could not create/open file)
 */

int read_file(int fd);
/* Read file by the file descriptor.
 * List all block which occupied by the opened file.
 * param : fd - position of the file in the directory entry array.
 * return : return number of block occupied by the file (block count) if success.
 * 			return -1 if failed to read file (the file have not opened).
 */

int write_file(int fd);
/* Write file by the file descriptor.
 * Allocate the first available disk block to the file.
 * param : fd position of the file in the directory entry array.
 * return : return 0 if success to allocate a block to the file.
 * 			return -1 if could not allocate a block to the file.
 *			(It happen when the file is not opened or disk full
 * 			or file size is over limit).
 */

int delete_file(int *fd);
/* Delete file by the file descriptor and set file descriptor to -1.
 * param : *fd pointer to the file descriptor.
 * 			(position of the file in the directory entry array).
 * return : return 0 if success to delete.
 * 			return -1 if can not delete file.
 */

void get_name_and_type( char fname[9], char ftype[4]);
/* Get file name and file type from input keyboard.
*/

void clear_stdin();
/* Clear standard input buffer,
 * purpose of this function is avoid wrong value of scanf function.
 * each call of getchar() eat an character of stdin.
 */
#endif

