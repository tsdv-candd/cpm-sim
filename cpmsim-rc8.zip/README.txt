===============================================================================================
			Solution explanation for the workshopE - CP/M simulation
===============================================================================================

1. Introduction:
~~~~~~~~~~~~~~~
    This document aim to explain solution for the requirement in workshopE.
    This workshop's requirement is implementing a File system simulator, based on the CP/M File system.
	
	Material for this presentation:
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    cpmold.c	: The original source code of the given by the workshopE.
    cpm.c       : The source code which already modify to resolve the problems.
    Makefile    : The make file used for compile cp1old.c and cp1.c to executable file.
    
    How to build program:
    ~~~~~~~~~~~~~~~~~~~~
    Simply run the make command under WorkShopE
    $ make
    After running make command, two executable files will be output:
    cpmsim		: The binary (executable file) which compiled from the source code cpm.c and cpm.h
				This executable is the operation of the CP/M simulation.

2. Overview about CP/M simulation requirement.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	. The disk size is 360 kbyte.
	. The smallest unit of allocation is 4 kbyte (block size = 4 kbyte)
		-> Total number of block = 360/4 = 90 blocks.
		Each bitmap array element (1 byte) can represent 8 block then 
		the bitmap array need 90/8 = 11.2 element round up to 12.

	. The maximum size of a file is 64 kbytes, each directory entry included 16 blocks of disk, 
		16 * 4 = 64. -> So there is only one directory entry per file.

	. The main directory occupies the first block of the disk (block 0), and its size is fixed at 1 block, 
		-> So there can only be 128 files in this file system.
		Then the directory entry need 128 element to store file control information.

	. As the directory always occupies only the first block, therefore no control information about it
	needs to be stored in the directory (i.e. no . entry).
	
3. Detail about the CP/M simulation solution
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	The task is to implement disk initialisation, including:
	creating the root directory, and a free bitmap for this disk.
	specify an empty directory ...etc. All of these operation a
	re simulate by following operation menu.
	
	3.1 Initialise Disk.
		Create and initialise disk control structures.
		Refer to the source file : cpm.c -> line 23 - line25
		Disk initialise operation is implemented by the function "disk_init"
		Refer to section 4.1. disk_init for more detail about it implementation

	How to test.
		Make sure the program already built by running 'make' command.
		$ make
		Run simulation then select the '1' after menu is display
		$ ./cpmsim
		----------------------------------
		CP/M simulation Menu
		----------------------------------
		0 - Exit
		1 - Initialise Disk
		2 - List Files in the Directory
		3 - Display the Free Bitmap
		4 - Open/Create File
		5 - Read File
		6 - Write File
		7 - Delete File
		----------------------------------
		Select number> 1
		After select '1' the function 'Initialise Disk' is called 
		Then directory will be empty and display the status as following.

	3.2 List Files in the Directory.
		Refer to the cpm.c -> line 34 -> line 36.
		This function is implemented in the function "list_file_in_dir()".
		Refer to section 4.2. list_file_in_dir for more detail about the implementation.
		
	How to test:
		Run simulation then select the '2' after menu is display
		$ ./cpmsim
		----------------------------------
				CP/M simulation Menu
		----------------------------------
		0 - Exit
		1 - Initialise Disk
		2 - List Files in the Directory
		3 - Display the Free Bitmap
		4 - Open/Create File
		5 - Read File
		6 - Write File
		7 - Delete File
		----------------------------------
		Select number> 2
		After select '2' all file in the directory will be listed in a table as following.		
		Note: 
		In case no file is created, the directory is empty and display.
		To create a file, used the option '4' and input 'file name' and 'file type'.
		
	3.3 Display the Free Bitmap.
		Display all bitmap table with detail status of each disk block.
		'0' is display if the block is free. 
		'1' is display if the block is occupied by a file.
		Refer to : cpm.c -> line 39 - line 42.
		This behaviour is implemented by the function disp_bit_map()
		For more detail, see the section 4.3. disp_bit_map().
		
	How to test:
		Run simulation then select the '3' after menu is display
		$ ./cpmsim
		----------------------------------
				CP/M simulation Menu
		----------------------------------
		0 - Exit
		1 - Initialise Disk
		2 - List Files in the Directory
		3 - Display the Free Bitmap
		4 - Open/Create File
		5 - Read File
		6 - Write File
		7 - Delete File
		----------------------------------
		Select number> 3
			After select '3' bitmap status will display all disk block status.
			Each block status is represent by a cell of the following table.
			Total 90 blocks so need 12 row, 8 column.

	3.4 Open/Create File.
		If the file name specified is in the directory, the file will be open.
		If the file name specified is not in the directory, a new file will be created.
		Refer to cpm.c -> line 44 to line 64 for detail of this implementation.
		This behaviour actually implemented in the function open_create_file.
		See section 4.4 open_create_file for detail.
	
	How to test:
		Run simulation then select the '4' after menu is display
		$ ./cpmsim
		----------------------------------
				CP/M simulation Menu
		----------------------------------
		0 - Exit
		1 - Initialise Disk
		2 - List Files in the Directory
		3 - Display the Free Bitmap
		4 - Open/Create File
		5 - Read File
		6 - Write File
		7 - Delete File
		----------------------------------
		Select number> 4
		After select '4' simulator will notify user input 'file name' and 'file type'.
		Then simulator do next steps base on selected name and type.
		Tip:
		Please use the menu '2' to list all file before using the option '4'.
	
	3.5 Read File.
		List the blocks occupied by the file (not the content of these blocks).
		Refer to the source file cpm.c -> line 66 to line 70.
		This behaviour is implemented by the function read_file(fd);
		Detail of this implementation is described at the section "4.5 read_file"
	
	How to test:
		Run simulation select menu '4' to open file then select the '5' to read file.
		----------------------------------
				CP/M simulation Menu
		----------------------------------
		0 - Exit
		1 - Initialise Disk
		2 - List Files in the Directory
		3 - Display the Free Bitmap
		4 - Open/Create File
		5 - Read File
		6 - Write File
		7 - Delete File
		----------------------------------
		Select number> 5
			The File: 'G.H' occupies 4 blocks at No: 1, 2, 3, 4,
		After select '5' simulator will display all block number which occupied by the opened file.	
		i.e : The file 'G.H' occupied 4 blocks No1, No.2, No.3, and No.4.
		Note: The file must be opened before read,
		Tips:
		Use the menu '2' to list all file then menu '4' to open a file in the list before read.
	
	3.6 Write File
		Allocate the first available block to the file.
		Refer to the cpmsim.c -> line 72 to line 77.
		This behaviour is implemented in the function write_file(fd)
		For detail of this implementation, refer to the section "3.6 write_file".

	How to test.
		Select the menu '6' after open file by menu '4'.
		----------------------------------
				CP/M simulation Menu
		----------------------------------
		0 - Exit
		1 - Initialise Disk
		2 - List Files in the Directory
		3 - Display the Free Bitmap
		4 - Open/Create File
		5 - Read File
		6 - Write File
		7 - Delete File
		----------------------------------
		Select number> 6
			INFO: The file 'G.H' is written at the block 5
	
	3.7 Delete file
		Deallocate all blocks, and free the directory entry.
		This delete operation can be done only in case the file is opened.
		Refer to the source code file : cpm.c -> line 79 to line 84.
		This behaviour is implemented in the function delete_file(fd)
		Refer to the section "4.7" for detail about the implementation of this function.
	
	How to test.
		1. Select '4' to create a file 'A.txt'
		2. Select '4' to create a file 'B.txt'
		3. Select '2' to list all files.
		4. Select '4' to open a file 'A.txt'
		5. Select '7' to delete 'A.txt'
		6. Select '2' to list all files. At this time, the fiel 'A.txt' is not listed.		
		----------------------------------
				CP/M simulation Menu
		----------------------------------
		0 - Exit
		1 - Initialise Disk
		2 - List Files in the Directory
		3 - Display the Free Bitmap
		4 - Open/Create File
		5 - Read File
		6 - Write File
		7 - Delete File
		----------------------------------
		Select number> 7
			The file 'A.txt' is deleted

4. Detail explanation for each function added to the file cpm.c
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	4.1 disk_init() : initialise the disk, deallocate all disk block and directory entry.
		prototype 	: void disk_init ()
		param 		: None
		return 		: None
	
	Steps of implementation.
		Step1 : Reset bitmap by calling the 'memset' system call.
		Step2 : Reset directory by calling the 'memset' system call.
		Step3 : Display the bitmap status by calling the function 'disp_bit_map'.
	
	4.2 list_file_in_dir : List all file in the directory.
		prototype : void list_file_in_dir();
		param : None.
		Return : None.
		
		Step of implementation.
		
		Step1 : Print the title of the table.
		Step2 : Print heading row of the table (file name, type and size).
		Step3 : Check all entries in directory entry.
				List all file in the directory if it existed.
				The file exist if the length of the file name greater 0.
		Step4 : In case the empty directory, just notify "Empty directory!"

	4.3 disp_bit_map : Display bit map status.
		Display status of all disk block in a table.
		Each block status is presented by a cell.
		If the block is free - the cell value will be '0'.
		If the block is occupied - the cell value will be '1'.
		Note: The block0 is defaulted occupied by the directory entry.
		Then the status of the block0 is not display here.
		prototype : void disp_bit_map();
		param : None.
		Return : None.
		
		Step of implementation.
		
		Step1 : Draw column index of the bitmap table.
		Step2 : Draw row index of the bitmap table.
		Step3 : Display blocks status after.
				0 - free block.
				1 - occupied block.
		
	4.4 open_create_file : Open/Create file 
		If the file name specified is not in the directory, a new file will be created.
		prototype : int open_create_file(char *fname, char *ftype)
		param : char * fname - pointer to the string of file name.
		param : char * ftype - pointer to the string of file type.
		return : return position of a file in case the file already existed.
				 return -1 of the file is open (file have not existed).
				 return -2 if error happened (could not create/open file)
		
		Step of implementation:
		Step1 : Check file name and ftype 
				If it Null, print message and return -2.
				If the the length is over limit, also print message and return -2.
		Step2 : Check all entries in directory.
				If the file existed (matched file name and file type)
					return the position of the file.
				If the file is not existed.
					create a file with input name and type.
					return -1.
	4.5 read_file : Read file by the file descriptor.
		List all block which occupied by the opened file.
		prototype : int read_file(int fd)
		param : fd - position of the file in the directory entry array.
		return : return number of block occupied by the file (block count) if success.
				 return -1 if failed to read file (the file have not opened).
		
		Step of implementation:
		Step1 : If the fd > -1, print block number which occupied by the file.
			Note : A file can occupied maximum 16 block but actual number of block
			occupied by the file is stored in the blockcount element of the directory entry.
		Step2 : Report Error in case the file is not opened yet.
		Step3 : Return number of block occupied by the file.
	
	4.6 write_file : Write file by the file descriptor.
		Allocate the first available disk block to the file.
		Prototype : int write_file(int fd);
		param : fd position of the file in the directory entry array.
		return : return 0 if success to allocate a block to the file.
				 return -1 if could not allocate a block to the file.
				 (It happen when the file is not opened or disk full
				 or file size is over limit).
		
		Step of implementation.
		Step1 : Report error if the file is not opened.
		Step2 : Report error if the file size is reach the limit of 64KB.
		Step3 : Allocate a block to the opened file.
		Step4 : Toggle a bitmap bit to mark that the block and ready occupied.
		Step5 : Report error of full disk if there is no block is allocate.
	
	4.7 delete_file : Delete file by the file descriptor and set file descriptor to -1.
		prototype : int delete_file(int *fd)
		param : *fd pointer to the file descriptor.
			    (position of the file in the directory entry array).
		return : return 0 if success to delete , return -1 if can not delete file.
		
		Step of implementation : 
		Step1 : Evaluate fd :
			Report error if fd is over limit of directory entries.
			Report error if fd < 0 (The file is not opened).
		Step2 : Free bitmap block appropriate to the block array occupied by the file.
		Step3 : Reset filename, filetype and block array of the file.
		Step4 : Set value of the fd to -1 to indicate that file is not open.
	
	4.8 get_name_and_type : Get file name and file type from input keyboard.
		prototype : int get_name_and_type( char fname[9], char ftype[4]);
		param : char fname[9] buffer to store input file name.
		param : char ftype[4] buffer to store input file type.
		return : None
		
		Steps of implementation:
		Step1 : Get file name.
		Step2 : Clear input buffer after get file name.
		Step3 : Get file type.
		Step4 : Clear input buffer after get file type.
	
	4.9 clear_stdin : Clear stdin after read input
		purpose of this function is avoid wrong value of next scanf function.
		prototype : void clear_stdin();
		param : None.
		return : None.
		
		Implementation.
		Call getchar() until the return value equal to '\n'.
		Each call of getchar() eats an character of stdin.
