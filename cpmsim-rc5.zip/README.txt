===============================================================================================
			Solution explanation for the workshopE - CP/M simulation
===============================================================================================

1. Introduction:
~~~~~~~~~~~~~~~
    This document aim to explain solution for the requirement in workshopE.
    This workshop's requirement is implementing a File system simulator, based on the CP/M File system.
	
	Material for this presentation:
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    cpmold.c	: The original source code of the given by the workshopE.
    cpm.c       : The source code which already modify to resolve the problems.
    Makefile    : The make file used for compile cp1old.c and cp1.c to executable file.
    
    How to build program:
    ~~~~~~~~~~~~~~~~~~~~
    Simply run the make command under WorkShopE
    $ make
    After running make command, two executable files will be output:
    cpmsim		: The binary (executable file) which compiled from the source code cpm.c and cpm.h
				This executable is the operation of the CP/M simulation.

2. Overview about CP/M simulation requirement.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	. The disk size is 360 kbyte.
	. The smallest unit of allocation is 4 kbyte (block size = 4 kbyte)
		-> Total number of block = 360/4 = 90 blocks.
		Each bitmap array element (1 byte) can represent 8 block then 
		the bitmap array need 90/8 = 11.2 element round up to 12.

	. The maximum size of a file is 64 kbytes, each directory entry included 16 blocks of disk, 
		16 * 4 = 64. -> So there is only one directory entry per file.

	. The main directory occupies the first block of the disk (block 0), and its size is fixed at 1 block, 
		-> So there can only be 128 files in this file system.
		Then the directory entry need 128 element to store file control information.

	. As the directory always occupies only the first block, therefore no control information about it
	needs to be stored in the directory (i.e. no . entry).
	
3. Detail about the CP/M simulation solution
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	The task is to implement disk initialisation, including:
	creating the root directory, and a free bitmap for this disk.
	specify an empty directory ...etc. All of these operation a
	re simulate by following operation menu.
	
	3.1 Initialise Disk.
		Create and initialise disk control structures.
		Refer to the source file : cpm.c -> line 23 - line25
		Disk initialise operation is implemented by the function "disk_init"
		Refer to section 4.1. disk_init for more detail about it implementation

	How to test.
		Make sure the program already built by running 'make' command.
		$ make
		Run simulation then select the '1' after menu is display
		$ ./cpmsim
		----------------------------------
		CP/M simulation Menu
		----------------------------------
		0 - Exit
		1 - Initialise Disk
		2 - List Files in the Directory
		3 - Display the Free Bitmap
		4 - Open/Create File
		5 - Read File
		6 - Write File
		7 - Delete File
		----------------------------------
		Select number> 1
		After select '1' the function 'Initialise Disk' is called 
		Then directory will be empty and display the status as following.
		----------------------------------------------------------------
				Select number> 1
				Bitmap status: 0 - free block, 1 - occupied block
				  0   1   2   3   4   5   6   7  <---- This is the index of the block in the bitmap.
				+---+---+---+---+---+---+---+---+
		0       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		1       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		2       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		3       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		4       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		5       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		6       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		7       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		8       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		9       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		10      | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		11      | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+

	3.2 List Files in the Directory.
		Refer to the cpm.c -> line 34 -> line 36.
		This function is implemented in the function "list_file_in_dir()".
		Refer to section 4.2. list_file_in_dir for more detail about the implementation.
		
	How to test:
		Run simulation then select the '2' after menu is display
		$ ./cpmsim
		----------------------------------
				CP/M simulation Menu
		----------------------------------
		0 - Exit
		1 - Initialise Disk
		2 - List Files in the Directory
		3 - Display the Free Bitmap
		4 - Open/Create File
		5 - Read File
		6 - Write File
		7 - Delete File
		----------------------------------
		Select number> 2
		After select '2' all file in the directory will be listed in a table as following.		
			List of files in directory:
			+-----------------------------------------------------------------------+
			|       File name       |       File type       |       File size       |
			+-----------------------------------------------------------------------+
			|       Test            |       txt             |       0KB             |
			+-----------------------------------------------------------------------+
		Note: 
		In case no file is created, the directory is empty and display.
		To create a file, used the option '4' and input 'file name' and 'file type'.
		---------------
			List of files in directory:
			+-----------------------------------------------------------------------+
			|       File name       |       File type       |       File size       |
			+-----------------------------------------------------------------------+
			Empty directory!
	
	3.3 Display the Free Bitmap.
		Display all bitmap table with detail status of each disk block.
		'0' is display if the block is free. 
		'1' is display if the block is occupied by a file.
		Refer to : cpm.c -> line 39 - line 42.
		This behaviour is implemented by the function disp_bit_map()
		For more detail, see the section 4.3. disp_bit_map().
		
	How to test:
		Run simulation then select the '3' after menu is display
		$ ./cpmsim
		----------------------------------
				CP/M simulation Menu
		----------------------------------
		0 - Exit
		1 - Initialise Disk
		2 - List Files in the Directory
		3 - Display the Free Bitmap
		4 - Open/Create File
		5 - Read File
		6 - Write File
		7 - Delete File
		----------------------------------
		Select number> 3
			After select '3' bitmap status will display all disk block status.
			Each block status is represent by a cell of the following table.
			Total 90 blocks so need 12 row, 8 column.

			Bitmap status: 0 - free block, 1 - occupied block
				  0   1   2   3   4   5   6   7
				+---+---+---+---+---+---+---+---+
		0       | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |	
				+---+---+---+---+---+---+---+---+
		1       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		2       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		3       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		4       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		5       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		6       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		7       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		8       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		9       | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		10      | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
		11      | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
				+---+---+---+---+---+---+---+---+
	
	3.4 Open/Create File.
		If the file name specified is in the directory, the file will be open.
		If the file name specified is not in the directory, a new file will be created.
		Refer to cpm.c -> line 44 to line 64 for detail of this implementation.
		This behaviour actually implemented in the function open_create_file.
		See section 4.4 open_create_file for detail.
	
	How to test:
		Run simulation then select the '4' after menu is display
		$ ./cpmsim
		----------------------------------
				CP/M simulation Menu
		----------------------------------
		0 - Exit
		1 - Initialise Disk
		2 - List Files in the Directory
		3 - Display the Free Bitmap
		4 - Open/Create File
		5 - Read File
		6 - Write File
		7 - Delete File
		----------------------------------
		Select number> 4
		After select '4' simulator will notify user input 'file name' and 'file type'.
		Then simulator do next steps base on selected name and type.
		Tip:
		Please use the menu '2' to list all file before using the option '4'.
	
	3.5 Read File.
		List the blocks occupied by the file (not the content of these blocks).
		Refer to the source file cpm.c -> line 66 to line 70.
		This behaviour is implemented by the function read_file(fd);
		Detail of this implementation is described at the section "4.5 read_file"
	
	How to test:
		Run simulation select menu '4' to open file then select the '5' to read file.
		----------------------------------
				CP/M simulation Menu
		----------------------------------
		0 - Exit
		1 - Initialise Disk
		2 - List Files in the Directory
		3 - Display the Free Bitmap
		4 - Open/Create File
		5 - Read File
		6 - Write File
		7 - Delete File
		----------------------------------
		Select number> 5
			The File: 'G.H' occupies 4 blocks at No: 1, 2, 3, 4,
		After select '5' simulator will display all block number which occupied by the opened file.	
		i.e : The file 'G.H' occupied 4 blocks No1, No.2, No.3, and No.4.
		Note: The file must be opened before read,
		Tips:
		Use the menu '2' to list all file then menu '4' to open a file in the list before read.
	
	3.6 Write File
		Allocate the first available block to the file.
		Refer to the cpmsim.c -> line 72 to line 77.
		This behaviour is implemented in the function write_file(fd)
		For detail of this implementation, refer to the section "3.6 write_file".

	How to test.
		Select the menu '6' after open file by menu '4'.
		----------------------------------
				CP/M simulation Menu
		----------------------------------
		0 - Exit
		1 - Initialise Disk
		2 - List Files in the Directory
		3 - Display the Free Bitmap
		4 - Open/Create File
		5 - Read File
		6 - Write File
		7 - Delete File
		----------------------------------
		Select number> 6
			INFO: The file 'G.H' is written at the block 5
	
	3.7 Delete file
		Deallocate all blocks, and free the directory entry.
		This delete operation can be done only in case the file is opened.
		Refer to the source code file : cpm.c -> line 79 to line 84.
		This behaviour is implemented in the function delete_file(fd)
		Refer to the section "4.7" for detail about the implementation of this function.
	
	How to test.
		1. Select '4' to create a file 'A.txt'
		2. Select '4' to create a file 'B.txt'
		3. Select '2' to list all files.
		4. Select '4' to open a file 'A.txt'
		5. Select '7' to delete 'A.txt'
		6. Select '2' to list all files. At this time, the fiel 'A.txt' is not listed.		
		----------------------------------
				CP/M simulation Menu
		----------------------------------
		0 - Exit
		1 - Initialise Disk
		2 - List Files in the Directory
		3 - Display the Free Bitmap
		4 - Open/Create File
		5 - Read File
		6 - Write File
		7 - Delete File
		----------------------------------
		Select number> 7
			The file 'A.txt' is deleted

4. Detail explanation for each function added to the file cpm.c
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	4.1. disk_init() : initialise the disk, deallocate all disk block and directory entry.
	prototype 	: void disk_init ()
	param 		: None
	return 		: None
	
	Steps of implementation.
		Step1 : Reset bitmap by calling the 'memset' system call.
		Step2 : Reset directory by calling the 'memset' system call.
		Step3 : Display the bitmap status by calling the function 'disp_bit_map'.
	
	